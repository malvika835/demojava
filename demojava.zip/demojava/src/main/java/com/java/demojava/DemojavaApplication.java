package com.java.demojava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemojavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemojavaApplication.class, args);
	}

}
