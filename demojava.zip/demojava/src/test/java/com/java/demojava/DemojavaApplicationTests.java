package com.java.demojava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemojavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
